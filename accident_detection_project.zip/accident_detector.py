
import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load the trained model
model = load_model('model/accident_cnn_model.h5')

# Load webcam or video file
cap = cv2.VideoCapture(0)  # or use a file: cv2.VideoCapture('accident_video.mp4')

while True:
    ret, frame = cap.read()
    if not ret:
        break

    img = cv2.resize(frame, (64, 64))
    img = np.expand_dims(img, axis=0) / 255.0

    prediction = model.predict(img)[0][0]
    
    label = "Accident Detected" if prediction > 0.5 else "Normal"
    color = (0, 0, 255) if prediction > 0.5 else (0, 255, 0)

    # Display label on video
    cv2.putText(frame, label, (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
    cv2.imshow('Accident Detection', frame)

    if cv2.waitKey(10) == 27:
        break

cap.release()
cv2.destroyAllWindows()
